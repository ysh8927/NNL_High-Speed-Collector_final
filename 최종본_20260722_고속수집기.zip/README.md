# 📡 wifi-collector

> **실내 위치 추정을 위한 WiFi RSSI + IMU 고속 수집 시스템**

라즈베리파이 + ESP32-S3 × 3 + Arduino Nano 33 BLE Rev2 조합으로
2.4GHz / 5GHz WiFi RSSI와 IMU 센서 데이터를 동시에 수집합니다.
수집된 데이터는 PDR(보행자 추측항법) 후처리를 거쳐 라디오맵 생성에 사용됩니다.
(2026.07.10 기준 5GHz는 DFS 채널(UNII-2A/2C)까지 포함한 25채널을 스캔합니다.)

---

## 📋 목차

- [시스템 개요](#시스템-개요)
- [하드웨어 구성](#하드웨어-구성)
- [소프트웨어 구성](#소프트웨어-구성)
- [폴더 구조](#폴더-구조)
- [설치 방법](#설치-방법)
- [사용 방법](#사용-방법)
- [출력 데이터 포맷](#출력-데이터-포맷)
- [전체 파이프라인](#전체-파이프라인)
- [2026.06.30 수정사항](#20260630-수정사항)
- [2026.07.02 수정사항](#20260702-수정사항)
- [2026.07.10 수정사항](#20260710-수정사항)
- [2026.07.22 수정사항](#20260722-수정사항)
- [주의사항](#주의사항)

---

## 시스템 개요

```
[수집 단계]
  Nano 33 BLE Rev2 (IMU)
        ↓ USB 시리얼
  라즈베리파이 ──────────────────────────────────────────→ raw CSV 저장
        ↑
  AWUS036AXML (5GHz 모니터모드 + tcpdump)
  ESP32-S3 × 3 (2.4GHz 채널 분할 스캔)

[후처리 단계 - 로컬 PC]
  raw CSV → PDR 연산 (회전보정 → x,y 경로) → 라디오맵 생성
```

### 핵심 성능

| 대역 | 방식 | 보드/채널 스캔 주기 | **AP(채널) 재방문 주기** | 하드웨어 |
|------|------|---------------------|---------------------------|---------|
| **5GHz** | 모니터모드 + tcpdump (DFS 포함 25채널 호핑, 50ms/채널) | 3.0 Hz (배치 기록) | 실측 MAC 재탐지율 **약 0.60 Hz** (기존 9채널 대비 ~1.0 Hz → 0.60 Hz) | AWUS036AXML (USB) |
| **2.4GHz** | ESP32-S3 × 3 채널 분할 스캔 (Board0/1: 4채널, Board2: 5채널) | Board0/1: 2.0 Hz / Board2: 1.74 Hz | Board0/1: **2.0 Hz** / Board2: **1.74 Hz** (12·13번 채널 포함) | ESP32-S3 × 3 |
| **IMU** | 하드웨어 타이머 | **50 Hz** ✅ | - | Nano 33 BLE Rev2 |

> ⚠️ "보드 스캔 주기"와 "특정 AP(채널) 재방문 주기"는 다른 개념입니다.
> 자세한 내용은 [2026.06.30 수정사항](#20260630-수정사항), [2026.07.02 수정사항](#20260702-수정사항), [2026.07.10 수정사항](#20260710-수정사항) 참고.

---

## 하드웨어 구성

### 메인 컴퓨터
| 항목 | 사양 |
|------|------|
| 모델 | Raspberry Pi 4 / 5 |
| OS | Ubuntu 22.04+ 또는 Raspberry Pi OS |
| Python | 3.8+ |

### WiFi 어댑터 (5GHz)
| 항목 | 사양 |
|------|------|
| 모델 | ALFA AWUS036AXML |
| 칩셋 | MT7921AUN |
| 연결 | USB 3.0 |
| USB ID | 0e8d:7961 |

### 2.4GHz 스캐너
| 항목 | 사양 |
|------|------|
| MCU | ESP32-S3 × 3개 |
| 채널 할당 | Board 0: CH 1,4,7,10(500ms,2.00Hz) / Board 1: CH 2,5,8,11(500ms,2.00Hz) / Board 2: CH 3,6,9,12,13(575ms,1.74Hz) |
| 통신 | USB 시리얼 921600 baud |
| 포트 | /dev/ttyUSB0 ~ ttyUSB2 |

### IMU 센서
| 항목 | 사양 |
|------|------|
| 모델 | Arduino Nano 33 BLE Rev2 |
| IMU 칩 | BMI270 (가속도 + 자이로) + BMM150 (지자기) |
| 라이브러리 | Arduino_BMI270_BMM150 |
| 통신 | USB 시리얼 921600 baud |
| 포트 | /dev/ttyACM0 |
| 샘플링 | **50 Hz** |
| 전원 | 5V 3A 어댑터 필수 (전류 부족 시 미인식) |

### 축 방향 (케이스 부착 기준)
```
        Z↑
        |
        |
        +──────→ X (진행방향/정면)
       /
      /
     Y (왼쪽)
```

---

## 소프트웨어 구성

| 파일 | 역할 | 실행 환경 |
|------|------|---------|
| `collect.py` | 전체 수집 통합 런처 | 라즈베리파이 (sudo) |
| `firmware/nano33_imu/nano33_imu.ino` | IMU 데이터 시리얼 출력 (50Hz) | Arduino Nano 33 BLE Rev2 |
| `scanner_5GHz/beacon_scanner.py` | 5GHz RSSI 수집 (3Hz 배치, DFS 포함 25채널 호핑 1주기 ≈ 1.25초) | 라즈베리파이 (root) |
| `scanner_2.4GHz/WiFi_2Hz_Final.ino` | 2.4GHz RSSI 수집 (보드 2Hz, 채널 재방문 2Hz) | ESP32-S3 × 3 |
| `scanner_2.4GHz/wifi_2ghz_receiver.py` | 2.4GHz 시리얼 수신 + CSV 저장 | 라즈베리파이 |
| `scripts/imu_receiver.py` | IMU 시리얼 수신 + 회전 시퀀스 + CSV 저장 | 라즈베리파이 |
| `scripts/setup_awus036axml.sh` | AWUS036AXML(MT7961) 펌웨어를 `/lib/firmware/mediatek/`에 설치 | 라즈베리파이 (sudo) |
| `AXML_Firmware_Linux_15APR2025/*.bin` | AWUS036AXML용 MT7961 WiFi/BT 펌웨어 바이너리 | - (설치 스크립트가 참조) |

---

## 폴더 구조

```
wifi-collector/
├── README.md
├── collect.py                             # 통합 런처 (전체 수집 한번에 시작)
├── firmware/
│   └── nano33_imu/
│       └── nano33_imu.ino                 # Nano 33 BLE Rev2 IMU 펌웨어 (50Hz)
├── scanner_5GHz/
│   └── beacon_scanner.py                  # 5GHz RSSI 고속 수집 (3Hz 배치)
├── scanner_2.4GHz/
│   ├── WiFi_2Hz_Final.ino                 # ESP32 펌웨어 (3보드, 채널 재방문 2Hz)
│   └── wifi_2ghz_receiver.py              # 2.4GHz 시리얼 수신 + CSV 저장
├── scripts/
│   ├── imu_receiver.py                    # IMU 시리얼 수신 + 회전 시퀀스 + CSV
│   └── setup_awus036axml.sh               # AWUS036AXML 펌웨어 설치 스크립트
└── AXML_Firmware_Linux_15APR2025/
    ├── WIFI_RAM_CODE_MT7961_1.bin
    ├── WIFI_MT7961_patch_mcu_1_2_hdr.bin
    └── BT_RAM_CODE_MT7961_1_2_hdr.bin
```

> ⚠️ 서버(FastAPI + KNN 매칭 엔진) 및 앱 코드는 이 저장소(고속수집기)에 포함되어 있지 않고 별도 저장소에서 관리됩니다.

---

## 설치 방법

### 1. 라즈베리파이 패키지 설치

```bash
sudo apt update
sudo apt install -y python3 python3-pip iw wireless-tools tcpdump
pip3 install pyserial
```

### 2. AWUS036AXML 드라이버 확인 및 펌웨어 설치

```bash
# USB 연결 확인
lsusb | grep "0e8d:7961"
# 출력 예시: Bus 001 Device 003: ID 0e8d:7961 MediaTek Inc. Wireless_Device

# 인터페이스 확인
iw dev
# 출력 예시: Interface wlx00c0cab90114
```

> `mt7921u` 모듈을 `/etc/modules`에 추가하면 부팅 시 자동 로드됩니다.

인터페이스가 잡히지 않거나 펌웨어가 없다는 로그(dmesg)가 보이면, 동봉된 MT7961 펌웨어를 설치합니다:

```bash
cd scripts
sudo ./setup_awus036axml.sh
sudo reboot
```

`AXML_Firmware_Linux_15APR2025/` 폴더의 `.bin` 파일들을 시스템 압축 형식(zstd/xz/gzip)에 맞춰 `/lib/firmware/mediatek/`에 설치합니다.

### 3. Nano 33 BLE Rev2 펌웨어 업로드

Arduino IDE에서:

1. **보드 설치**: `툴 → 보드 → 보드 관리자` → `Arduino Mbed OS Nano Boards` 설치
2. **라이브러리 설치**: `툴 → 라이브러리 관리자` → `Arduino_BMI270_BMM150` 설치
3. **보드 선택**: `툴 → 보드 → Arduino Nano 33 BLE`
4. **포트 선택**: `툴 → 포트 → /dev/ttyACM0` (또는 COMx)
5. `firmware/nano33_imu/nano33_imu.ino` 업로드

업로드 후 시리얼 모니터(921600 baud)에서 아래와 같이 출력되면 정상:
```
READY,NANO33_IMU
INFO,ACCEL_RATE,50.00
INFO,GYRO_RATE,50.00
IMU,1234,0.0012,-0.0034,1.0021,0.1200,-0.0340,0.0120
```

> ⚠️ 전원은 반드시 **5V 3A 어댑터**를 사용하세요. 전류가 부족하면 보드 자체가 인식되지 않습니다 (USB 대역폭 문제 아님).

### 4. ESP32-S3 펌웨어 업로드

Arduino IDE에서:

1. **보드 설치**: `툴 → 보드 → 보드 관리자` → `esp32` 설치
2. **보드 선택**: `툴 → 보드 → ESP32S3 Dev Module`
3. `scanner_2.4GHz/WiFi_2Hz_Final.ino` 를 **3개 보드 모두**에 각각 업로드

> ⚠️ 보드 MAC 주소 매핑이 코드에 하드코딩되어 있습니다.
> 보드 교체 시 MAC 주소 확인 후 `WiFi_2Hz_Final.ino` 내 boardID 매핑 수정 필요.

현재 MAC 매핑:
```cpp
Board 0: mac[4] == 0xb9  // b6:b9:70
Board 1: mac[5] == 0x2c  // b7:3b:2c
Board 2: mac[5] == 0xb4  // b7:32:b4
```

채널 할당 (boardID 기준):
```
Board 0 → CH 1, 4, 7, 10          (4채널, 500ms 틱)
Board 1 → CH 2, 5, 8, 11          (4채널, 500ms 틱)
Board 2 → CH 3, 6, 9, 12, 13      (5채널, 575ms 틱)
```
3개 보드가 채널을 나눠서 담당하며, 국내(KCC) 허용 채널 1~13번을 빠짐없이 커버합니다.
Board 0/1은 500ms 틱마다 담당 채널 4개를 전부 스캔하므로(115ms×4=460ms), **채널(=AP) 재방문 주기가 2Hz**입니다.
Board 2는 5채널을 담당하는 대신 틱 주기를 575ms로 연장(115ms×5=575ms)하여, **채널(=AP) 재방문 주기가 1.74Hz**입니다. dwell time(115ms)과 비콘 지터 마진은 세 보드 모두 동일하게 유지되므로 확률적 미탐지 위험은 늘어나지 않습니다. 자세한 배경은 [2026.07.02 수정사항](#20260702-수정사항) 참고.

---

## 사용 방법

### 통합 런처로 한번에 시작 (권장)

```bash
sudo python3 collect.py
```

실행하면 순서대로 입력을 요청합니다:

```
장소명 입력 (예: 공학관_3층): 공학관_3층

회전 시퀀스 입력 (예: 우90,좌90,180)
없으면 Enter (직선 경로)
회전 시퀀스: 우90,180
```

입력 완료 후 3개 수집이 동시에 시작되고 `Ctrl+C` 로 전체 종료됩니다.

---

### 개별 실행 (디버깅용)

#### 터미널 1 — IMU 수신

```bash
cd scripts
python3 imu_receiver.py
```

#### 터미널 2 — 5GHz RSSI 수집

```bash
cd scanner_5GHz
sudo python3 beacon_scanner.py -i wlx00c0cab90114 --location 공학관_3층
```

#### 터미널 3 — 2.4GHz RSSI 수집

```bash
cd scanner_2.4GHz
python3 wifi_2ghz_receiver.py --location 공학관_3층
```

> ESP32는 USB 연결 후 자동으로 스캔을 시작합니다.

---

## 출력 데이터 포맷

수집 완료 후 `data/` 폴더에 3개 CSV 파일이 생성됩니다.

### IMU 데이터 (`imu_<장소명>_<날짜시간>.csv`)

```csv
timestamp,board_ts_ms,ax,ay,az,gx,gy,gz,rotation_hint
2026-06-02 15:30:00.123,12340,0.0012,-0.0034,1.0021,0.12,-0.03,0.01,
2026-06-02 15:30:01.234,13451,0.12,0.34,0.98,45.0,-2.3,1.2,ROT_R90_1
```

| 컬럼 | 설명 | 단위 |
|------|------|------|
| timestamp | 라즈베리파이 수신 시각 | - |
| board_ts_ms | Nano 33 내부 타이머 | ms |
| ax, ay, az | 가속도 (X/Y/Z축) | g |
| gx, gy, gz | 자이로 (X/Y/Z축) | deg/s |
| rotation_hint | 회전 이벤트 감지 시 기록 | - |

### 5GHz RSSI 데이터 (`rssi_5ghz_<장소명>_<날짜시간>.csv`)

```csv
timestamp,38:17:C3:C2:14:90,38:17:C3:C2:14:92,...
2026-06-02 15:30:00.157,-72:52,-65:149,...
2026-06-02 15:30:00.557,-73:52,,...
```

### 2.4GHz RSSI 데이터 (`rssi_2.4ghz_<장소명>_<날짜시간>.csv`)

```csv
timestamp,AA:BB:CC:11:22:33,DD:EE:FF:44:55:66,...
2026-06-02 15:30:00.198,-45:6,-67:1,...
2026-06-02 15:30:00.698,-46:6,,...
```

- 타임스탬프 기준 Wide 포맷 (AP가 많아질수록 가로로 길어짐)
- **감지되지 않은 AP는 빈칸 (= -100dBm으로 간주, 후처리 시 평균 계산에서 제외)**
- **(2026.07.22~) 셀 값 형식이 `RSSI:CHANNEL`로 변경됨** (예: `-65:52`). 기존 분석 코드는 `split(':')`로 파싱 필요 — 자세한 내용은 [2026.07.22 수정사항](#20260722-수정사항) 참고

---

## 전체 파이프라인

```
[고속수집기]
  ① Nano 33 BLE Rev2 → IMU 50Hz 시리얼 출력
  ② imu_receiver.py  → 시리얼 수신 + 회전 감지 → imu_장소명_날짜.csv
  ③ beacon_scanner.py → 5GHz RSSI 3Hz → rssi_5ghz_장소명_날짜.csv
  ④ wifi_2ghz_receiver.py + ESP32 × 3 → 2.4GHz RSSI 2Hz → rssi_2.4ghz_장소명_날짜.csv

[후처리 - 로컬 PC]
  ⑤ IMU CSV → PDR 연산 (회전보정 적용 → x,y 경로 생성)
  ⑥ x,y 경로 + RSSI CSV 병합 → 라디오맵 생성
     (RP 근접 지점 RSSI 평균 시 -100 제외, 채널 호핑 주기 이상의 윈도우 권장)

[서버 업로드]
  ⑦ 라디오맵 → Supabase DB 수동 업로드

[앱]
  ⑧ RSSI 스캔 → FastAPI KNN 매칭 → 도면 위 위치 표시
```

---

## 2026.06.30 수정사항

수집 raw 데이터 검증 중, 동일 MAC의 RSSI가 특정 시점에 빈칸으로 사라지는 패턴이 발견되어 원인을 분석하고 아래와 같이 수정했습니다.

### 2.4GHz — `WiFi_2Hz_Final.ino`

**문제**: 기존 코드는 500ms 틱마다 담당 채널 4개 중 **1개씩만** 순환 스캔(`channelIndex` 방식)했습니다. 그 결과 보드 자체는 2Hz로 동작하지만, 특정 채널(=특정 AP)의 실제 재방문 주기는 `500ms × 4채널 = 2초(0.5Hz)`로 4배 느렸습니다. raw 데이터에서도 동일 MAC이 정확히 2초 간격으로만 값이 찍히고 나머지는 빈칸인 패턴이 확인되어 원인이 일치함을 검증했습니다.

**수정**: `performScan()`을 한 틱(500ms) 안에서 담당 채널 4개를 모두 순회하도록 변경(`for`문, 115ms×4=460ms < 500ms 예산). 이를 통해 채널(=AP) 재방문 주기가 목표치인 **2Hz로 회복**되었습니다.

> 실제 보드 플래시 후, 채널 전환 오버헤드까지 포함해 한 사이클이 정말 500ms 안에 끝나는지(`SCANEND` 로그 간격) 실측 검증이 필요합니다.

#### dwell time 80ms → 115ms 조정 (2026.06.30 추가)

**문제**: 채널당 80ms 패시브 스캔창은 AP의 일반적인 비콘 주기(100ms)보다 짧아, 비콘 타이밍과 스캔창이 우연히 어긋나면 해당 채널 사이클에서 비콘을 통째로 놓치는 확률적 미탐지가 발생. 실측 raw CSV에서 간격이 정확히 0.5초 배수(0.5, 1.0, 1.5초...)로 몰리는 패턴으로 확인됨 — 코드 결함이 아니라 80ms 스캔창과 100ms 비콘 주기 사이의 물리적 미스매치.

**검토한 대안**:
| dwell time | 4채널 합산 | 500ms 대비 슬랙 | 비콘 포착 마진 |
|---|---|---|---|
| 80ms | 320ms | 180ms | 비콘 주기(100ms)보다 짧아 누락 발생 |
| 101ms | 404ms | 96ms | 이론적 최소값이나 비콘 지터(jitter) 흡수 마진 없음 |
| **115ms** | **460ms** | **40ms** | **비콘 지터 흡수 + 사이클 오버헤드 흡수 균형** |
| 125ms | 500ms | 0ms | 슬랙 없음 → 채널 전환/파싱 오버헤드로 사이클 오버런(드리프트) 위험 |

**결정**: 115ms로 설정. 100ms 비콘 주기 대비 +15ms 마진으로 일반적인 비콘 지터(CSMA/CA로 인한 송신 지연)를 흡수하면서도, 500ms 타이밍 버짓 안에 40ms 슬랙을 남겨 채널 전환·파싱·UART 출력 오버헤드를 흡수.

> 플래시 후 비콘 포착률(채널 재방문 간격이 0.5초에 몰리는 비율)과 사이클 소요시간(SCANEND 로그 간격이 500ms를 벗어나는지)을 실측 검증 필요. 만약 500ms 초과(드리프트)가 관측되면 `scan_time.passive`를 110ms 수준으로 낮추는 재조정이 필요할 수 있습니다.

### 5GHz — `beacon_scanner.py`

**문제**: 기존 `APDataStore.get_recent(max_age_sec=2.0)`는 "최근 2초 이내 잡힌 적 있는 모든 AP"를 매 배치(약 333ms)마다 반복 반환하는 캐싱 구조였습니다. 그 결과 같은 비콘 1회 측정값이 여러 배치(최대 약 9초 관측)에 걸쳐 재사용되는 **RSSI 신선도(staleness) 문제**가 있었습니다. 실내 측위(특히 PDR 기반 연속 보행 수집)에서는 사람이 이동 중이므로, 옛 위치에서 측정된 신호가 현재 위치에 매칭되는 시간-위치 불일치로 이어질 수 있어 일반 빈칸 문제보다 더 치명적입니다.

**수정**:
1. `APDataStore`에 `reported` 플래그를 추가하여, 한 번 배치에 포함된 값은 새 비콘이 들어오기 전까지 재사용하지 않도록 변경.
2. `run()` 루프에서 새로 잡힌 AP가 없는 사이클도 행을 기록하도록 변경(`if aps:` 조건 제거) — 타임스탬프 간격을 일정하게 유지하고, 값이 없는 AP는 2.4GHz와 동일하게 빈칸으로 정직하게 표시.

> 이 수정으로 빈칸 비율은 다소 늘어날 수 있으나(9채널 호핑 주기 0.45초 내에 비콘을 못 들으면 진짜 빈칸 처리), 실내 측위 정확도 관점에서는 "오래된 값을 재사용하는 것"보다 "정직한 빈칸"이 더 안전한 선택입니다.

---

## 2026.07.02 수정사항

### 2.4GHz 채널 12 누락 문제 해결

**문제**: 국내(KCC) 기준 2.4GHz는 채널 1~13번을 전부 허용하지만, 기존 3보드 채널 할당(Board 0: 1,4,7,10 / Board 1: 2,5,8,11 / Board 2: 3,6,9,13)은 총 12채널만 커버하여 **채널 12가 스캔 대상에서 완전히 빠져 있었습니다.** 시스템이 원래 4보드 체제로 설계될 당시에는 14채널(일본 포함) 전체를 4보드에 고르게 분배했으나, 이후 하드웨어를 3보드로 축소하면서 "보드당 4채널"이라는 옛 수치를 그대로 유지한 데서 발생한 설계 사각지대입니다.

**검토한 대안**:
| 방안 | 내용 | 채택 여부 |
|---|---|---|
| 12/13 채널 교대 스캔 | 짝/홀 틱마다 12번과 13번을 번갈아 배정 | 기각 — 특정 채널이 1Hz로 반토막 |
| 13번 제외, 12번으로 교체 | Board2를 3,6,9,12로 변경 | 기각 — 국내는 1~13 전체 허용 지역이라 13번도 정상 사용 채널, 순손실 없이 빠지는 채널만 바뀌는 셈 |
| **Board2만 5채널 확장 + 틱 주기 연장** | Board2 채널을 3,6,9,12,13(5개)로, 그 보드의 타이머 주기만 575ms로 연장 | **채택** |

**수정**: `WiFi_2Hz_Final.ino`에서 Board2만 아래와 같이 변경했습니다.
```cpp
const uint8_t CHANNELS_BOARD2[] = {3, 6, 9, 12, 13};  // 4개 → 5개
// Board2 전용 타이머 주기
SCAN_INTERVAL_US_BOARD2 = 575000;  // 500ms → 575ms (115ms × 5채널)
```
- dwell time(115ms)과 비콘 지터 마진(+15ms)은 그대로 유지 — Board0/1의 기존 검증 결과(1시간 런타임 테스트)에 영향 없음
- Board2 담당 5채널(3, 6, 9, 12, 13) 전부가 균등하게 **1.74Hz**로 재방문 (채널 12: 0Hz → 1.74Hz, 채널 13: 2Hz → 1.74Hz)
- Board0/1은 기존과 동일하게 4채널, 500ms 틱, 2Hz 유지 — 영향 없음

> 플래시 후 Board2의 `SCANEND` 로그 간격이 실제로 575ms 근처에서 안정적인지 실측 검증이 필요합니다.

---

## 2026.07.10 수정사항

### 5GHz DFS 채널 추가 — `beacon_scanner.py`

**배경**: 2026.07.10 미팅에서 5GHz 스캔 대상을 기존 UNII-1/UNII-3 9채널(36~48, 149~165)에서 DFS 채널(UNII-2A/2C)까지 확장할 수 있는지 확인이 액션아이템으로 지정됨. 모니터 모드는 수신 전용(TX 없음)이라 CAC(레이더 감지) 절차 없이 `iw set freq`로 채널만 튜닝하면 되므로 이론적으로는 DFS 채널도 그대로 스캔 가능할 것으로 판단, 실기 검증 진행.

**수정**: `CHANNELS_5GHZ_WITH_DFS` 상수를 추가하여 스캔 채널을 기존 9개에서 25개로 확장.
```python
# 기존 비DFS 9채널 (UNII-1 + UNII-3) — 폴백/비교용으로 유지
CHANNELS_5GHZ_NO_DFS = [36, 40, 44, 48, 149, 153, 157, 161, 165]

# DFS 포함 전체 25채널
CHANNELS_5GHZ_WITH_DFS = [
    36, 40, 44, 48,           # UNII-1
    52, 56, 60, 64,           # UNII-2A (DFS)
    100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144,  # UNII-2C (DFS)
    149, 153, 157, 161, 165   # UNII-3
]

# 실제 사용할 채널 리스트 (여기서 전환: DFS 없이 되돌리려면 CHANNELS_5GHZ_NO_DFS로 변경)
CHANNELS_5GHZ = CHANNELS_5GHZ_WITH_DFS
```
`ACTIVE_CHANNELS_5GHZ` 역할을 하는 `CHANNELS_5GHZ` 대입 한 줄만 바꾸면 DFS 포함/제외를 즉시 전환할 수 있도록 설계함.

**검증 결과**:
- 채널이 9개 → 25개로 늘어나면서 5GHz MAC 재탐지율이 기존 약 1.0 Hz에서 약 0.60 Hz로 낮아짐. 채널 수 증가에 따른 예상된 트레이드오프이며, 이론적으로 기대한 방향과 일치함을 확인.
- 스마트폰(레퍼런스) 대비 고속수집기의 미탐지 MAC 개수를 DFS 적용 전/후로 비교한 결과, phone-only(고속수집기가 놓친 MAC) 건수가 67건 → 11건으로 크게 감소.
- 남은 11건은 신호가 약한 non-DFS 채널 대역 기기로, DFS 채널 확장과는 무관한 별개의 미탐지 원인으로 확인됨.

> 결론: DFS 채널 미스캔이 스마트폰 대비 고속수집기의 MAC 탐지 격차의 주된 구조적 원인이었으며, 이번 수정으로 격차의 대부분이 해소됨.

---

## 2026.07.22 수정사항

### CSV에 채널 번호 저장 — `beacon_scanner.py`, `wifi_2ghz_receiver.py`

**배경**: JPNT 논문 작성 중, 고속수집기가 스마트폰보다 추가로 탐지한 AP들이 어느 채널(특히 DFS 여부)에서 왔는지 분석하려 했으나, 기존 CSV에는 RSSI만 저장되고 채널 정보가 없어 분석이 불가능했음.

**5GHz (`beacon_scanner.py`)**: `APDataStore`는 이미 `channel` 필드를 내부적으로 계산하고 있었지만 `CSVWriter`가 RSSI만 기록하고 있었음. `write_batch()`의 snapshot 생성 부분을 수정하여 셀 값을 `RSSI` → `RSSI:CHANNEL` 형식으로 변경.

**2.4GHz (`wifi_2ghz_receiver.py`)**: ESP32가 시리얼로 `boardID,MAC,SSID,RSSI,Channel,SCAN` 형식으로 채널을 이미 전송하고 있었으나, 리시버가 `parts[3]`(RSSI)만 읽고 `parts[4]`(Channel)는 버리고 있었음. `read_board()`에서 채널을 추출해 `WideCSVWriter.write()`에 전달하고, 셀 값을 `RSSI:CHANNEL` 형식으로 저장하도록 수정.

```csv
# 변경 전
timestamp,AA:BB:CC:DD:EE:01
2026-07-22 17:48:42.372,-65

# 변경 후
timestamp,AA:BB:CC:DD:EE:01
2026-07-22 17:48:42.372,-65:52
```

> ⚠️ **하위 호환 깨짐 주의**: 이 버전부터 수집된 CSV는 셀 값이 `"RSSI:CHANNEL"` 문자열이라 기존 분석 스크립트에서 곧바로 `int()` 변환하면 오류가 납니다. `rssi, channel = cell.split(':')`로 먼저 분리해야 합니다. 채널 파싱 실패 시(주파수 미상) 5GHz는 `channel=0`으로 기록됩니다.

---

## 주의사항

### 모니터 모드
- `beacon_scanner.py` 실행 중에는 AWUS036AXML로 인터넷 연결 불가
- 종료 시 자동으로 managed 모드로 복원됨
- root 권한 필요 (`sudo`)

### USB 전력
- 라즈베리파이 USB 전력 부족 시 어댑터 인식 불안정
- 유전원 USB 허브 사용 권장 (패시브 허브는 모니터 연결 시 전원 문제 발생 가능)
- 또는 `/boot/firmware/config.txt` 에 `max_usb_current=1` 추가 후 재부팅

### ESP32 보드 MAC 매핑
- 보드 교체 시 `WiFi_2Hz_Final.ino` 내 boardID 매핑 수정 필요
- 시리얼 모니터에서 MAC 주소 확인 후 코드 업데이트
- `WiFi.macAddress()`는 `WiFi.mode()` 초기화 이후에 호출해야 정상 값이 나옵니다 (초기화 전 호출 시 00:00:00 출력됨)

### 채널 호핑 구조 이해
- 2.4GHz/5GHz 모두 한 번에 전체 채널을 보는 게 아니라 채널을 나눠서/순환하며 스캔합니다.
- 라디오맵 생성 시 RSSI 평균을 낼 때는 이 채널 재방문 주기(2.4GHz: 2Hz, 5GHz: DFS 포함 25채널 호핑 기준 실측 재탐지율 약 0.60Hz) 이상의 시간 윈도우를 사용해야 특정 채널 AP가 누락되지 않습니다.
- 5GHz는 `CHANNELS_5GHZ` 대입부에서 `CHANNELS_5GHZ_WITH_DFS` / `CHANNELS_5GHZ_NO_DFS` 중 선택해 DFS 채널 포함 여부를 전환할 수 있습니다. DFS 채널을 켜면 미탐지 MAC 수는 크게 줄지만 재방문 주기는 느려지므로, 성능 분석 시 반드시 **MAC 단위 재탐지율(실질 탐지율)** 기준으로 평가해야 하며 단순 row 개수 비교는 지양합니다.

### 동시 수집 타이밍
- IMU와 RSSI는 별도 파일로 저장됨
- 후처리 단계에서 `timestamp` 컬럼 기준으로 병합
- 통합 런처(`collect.py`) 사용 권장

---

## 개발 환경

| 항목 | 버전 |
|------|------|
| Python | 3.8+ |
| pyserial | 3.5+ |
| Arduino IDE | 2.x |
| Arduino Mbed OS Nano Boards | 4.x |
| Arduino_BMI270_BMM150 | 1.x |
| esp32 (Arduino) | 2.x |

---

## 개발자

- **ysh8927** - 한림대학교 AI융합연구원 / Next Navigation Lab (NNL)
- GitHub: https://github.com/ysh8927/wifi-collector
